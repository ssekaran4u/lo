import React from 'react';
import './App.css';
import Web from './router/web';



function App() {
  return (
    <div className="App">
      <Web />
    </div>
  );
}

export default App;
