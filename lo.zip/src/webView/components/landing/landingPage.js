import React from 'react'

/**
* @author
* @function LandingPae
**/

const LandingPae = (props) => {
  return(
    <div>LandingPae</div>
   )

 }

export default LandingPae