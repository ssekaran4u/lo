import LandingPage from "./landingPage";
export const LandingPageContainer = LandingPage;