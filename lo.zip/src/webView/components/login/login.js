import React, { useState } from "react";
import phone from "../../../assets/images/phone.svg";
import password from "../../../assets/images/password.svg";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";

import { IconButton } from "@material-ui/core";
import eye from "../../../assets/images/eye.svg";
import eyeOff from "../../../assets/images/eyeOff.svg";

/**
* @author
* @function Login
**/

const Login = (props) => {
  const {
    
    changeFunction, blurFunction,
    loginProcess,
    forgot,
    inputs,
    errors,
    errorMessage,
    loading
  } = props;
  console.log(blurFunction,"blurFunction")
  const [values, setValues] = React.useState({
    showPassword: false,
  });
  const [showPassword, setShowPassword] = useState(false);
  const handlePassword = () => {
    setShowPassword(!showPassword);
  };

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
  };
  return (
    <>
      
    </>
  )

}

export default Login