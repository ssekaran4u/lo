export const ENV={
    BASE_URL: "https://www.datasense.in/c2/lc/ms"
}