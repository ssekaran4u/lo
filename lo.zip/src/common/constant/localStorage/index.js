export const LocalStorage={
    NAME: "NAME",
    MOBILE_NO: "MOBILE_NO",
    PASSWORD: "PASSWORD",
    CUST_ID: "CUST_ID",
    TOKEN: "TOKEN"
}